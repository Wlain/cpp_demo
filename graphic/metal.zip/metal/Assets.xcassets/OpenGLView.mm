//
//  OpenGLView.m
//  OpenGL-Mac
//
//  Created by william on 2020/2/19.
//  Copyright © 2020 william. All rights reserved.
//

#import "OpenGLView.h"

#define STB_IMAGE_IMPLEMENTATION



@interface OpenGLView()

@end


@implementation OpenGLView

- (BOOL)acceptsFirstResponder {
    return YES;
}

- (void)keyDown:(NSEvent *)event {

}

- (void)keyUp:(NSEvent *)event {

}

- (void)rightMouseDown:(NSEvent *)event {
    CGEventRef tempEvent = CGEventCreate(NULL);
}

- (void)rightMouseUp:(NSEvent *)event {
}

- (void)rightMouseDragged:(NSEvent *)event {

}

- (void)prepareOpenGL {
    [super prepareOpenGL];
    [NSTimer scheduledTimerWithTimeInterval:1.0/60.0 target:self selector:@selector(renderOneFrame) userInfo:nil repeats:YES];
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    NSLog(@"drawRect");
    // Drawing code here.
}

- (void)renderOneFrame {
    // 帧率60
    [self setNeedsDisplay:YES];
}

@end
