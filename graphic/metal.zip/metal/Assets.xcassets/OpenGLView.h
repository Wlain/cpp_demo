//
//  OpenGLView.h
//  OpenGL-Mac
//
//  Created by william on 2020/2/19.
//  Copyright © 2020 william. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface OpenGLView : NSOpenGLView

@end

NS_ASSUME_NONNULL_END
