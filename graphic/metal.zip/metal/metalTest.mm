//
// Created by william on 2021/11/18.
//

#import <Cocoa/Cocoa.h>

int metalTest(int argc, const char* argv[])
{
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
